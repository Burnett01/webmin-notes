do 'webmin-notes-lib.pl';

sub is_installed
{
	my ($mode) = @_;
	return $mode + 1;
}

